from django.shortcuts import render
from aniachi.systemUtils import Welcome as W
from django.http import JsonResponse, HttpResponse, HttpResponseForbidden
import json
import psutil
from django.views.decorators.csrf import csrf_exempt
from .utils import getDictFromHL7, value_or_default
from django.views.decorators.csrf import csrf_exempt

# Create your views here.


def serverInfoView(req):
    """
    for educational purposes


Returns:
    HttpResponse -- Response object with all intalled python modules
"""
    W.get_all_libs('json')
    return JsonResponse(json.loads(W.get_fetchdata(format='json')), safe=False)


"""
    for educational purposes


Returns:
    HttpResponse -- Response object with all intalled python modules
"""


def defaultHomeView(req):
    return HttpResponse('<h1>Home</h1>')


"""
    for educational purposes


Returns:
    HttpResponse -- Response object with all intalled python modules
"""


def processView(req):
    ps = list()
    for proc in psutil.process_iter():
        ps.append(proc.as_dict(
            attrs=['pid', 'name', 'cpu_percent', 'username']))

    print(ps)
    return JsonResponse(ps, safe=False)


"""
    for educational purposes


Returns:
    HttpResponse -- Response object with all intalled python modules
"""


def installedModulesView(req):
    return HttpResponse(W.get_all_libs(), content_type='application/json')



#
# TODOS MORE INFO
#

def ViewHL7(request):
    d={}
    format='json'

    return HttpResponse(json.dumps(d), content_type='application/json')






def _403View(req):
    return HttpResponseForbidden()