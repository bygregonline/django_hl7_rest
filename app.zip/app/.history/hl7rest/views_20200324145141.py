from django.shortcuts import render
from aniachi.systemUtils import Welcome as W
# Create your views here.
def ServerInfoView()