from django.shortcuts import render
from aniachi.systemUtils import Welcome as W
from django.http import JsonResponse, HttpResponse
import json
import psutil

# Create your views here.


def serverInfoView(req):
    W.get_all_libs('json')
    return JsonResponse(json.loads(W.get_fetchdata(format='json')), safe=False)


def defaultHomeView(req):
    return HttpResponse('<h1>Home</h1>')


def processView(req):
    ps = list()
    for proc in psutil.process_iter():
        ps_info = proc.as_dict(attrs=['pid', 'name', 'cpu_percent'])
    return JsonResponse(json.loads(W.get_fetchdata(format='json')), safe=False)


def installedModulesView(req):
    return HttpResponse(W.get_all_libs(), content_type='application/json')
