

from django import forms


class RegistrationForm(forms.Form):

    format = forms.CharField(max_length=100,
                               widget=forms.TextInput(
                                   attrs={'class': 'form-control', 'placeholder': 'username'})
                               )
    data = forms.CharField(max_length=100, widget=forms.PasswordInput(
        attrs={'class': 'form-control', 'autocomplete': 'off', 'placeholder': 'password'})
    )

