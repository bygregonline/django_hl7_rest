

def getDictFromHL7(segment):
    """[summary]

    Arguments:
        segment {[type]} -- [description]

    Returns:
        [type] -- [description]
    """
    d = {}
    d['version'] = segment.version
    d['field'] = segment.name

    data = {}

    for s in segment.children:
        data[s.long_name] = s.value.replace('^', ' ')

    d['data'] = data

    return d
