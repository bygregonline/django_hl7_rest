

from django import forms
FAVORITE_COLORS_CHOICES = [
    ('json', 'json'),
    ('green', 'Green'),
    ('black', 'Black'),
]


class Simple_submit_Form(forms.Form):


    data = forms.CharField(max_length=100, widget=forms.TextInput(
        attrs={'class': 'form-control', 'autocomplete': 'off', 'placeholder': 'password'}))

    """[summary]
    """
    format = favorite_colors = forms.ChoiceField(
        choices=FAVORITE_COLORS_CHOICES, widget=forms.Select(attrs={'class': 'form-control'}))
