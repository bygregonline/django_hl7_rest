

from django import forms


class Simple_submit_Form(forms.Form):
    FAVORITE_COLORS_CHOICES = [
        ('blue', 'Blue'),
        ('green', 'Green'),
        ('black', 'Black'),
    ]

    format = forms.CharField(max_length=100,
                             widget=forms.TextInput(
                                 attrs={'class': 'form-control', 'placeholder': 'username'})
                             )
    data = forms.CharField(max_length=100, widget=forms.TextInput(
        attrs={'class': 'form-control', 'autocomplete': 'off', 'placeholder': 'password'}))

    """[summary]
    """
    favorite_colors = forms.ChoiceField(
        widget=forms.ChoiceField(choices=FAVORITE_COLORS_CHOICES))
