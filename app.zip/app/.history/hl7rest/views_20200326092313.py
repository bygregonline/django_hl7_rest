from django.shortcuts import render
from aniachi.systemUtils import Welcome as W
from django.http import JsonResponse, HttpResponse
import json
import psutil

# Create your views here.


def serverInfoView(req):
    W.get_all_libs('json')
    return JsonResponse(json.loads(W.get_fetchdata(format='json')), safe=False)


def defaultHomeView(req):
    return HttpResponse('<h1>Home</h1>')

"""[summary]

Returns:
    [type] -- [description]
"""
def processView(req):
    ps = list()
    for proc in psutil.process_iter():
        ps.append(proc.as_dict(
            attrs=['pid', 'name', 'cpu_percent', 'username']))

    print(ps)
    return JsonResponse(ps, safe=False)

"""[summary]


Returns:
    [type] -- [description]
"""
def installedModulesView(req):
    return HttpResponse(W.get_all_libs(), content_type='application/json')
