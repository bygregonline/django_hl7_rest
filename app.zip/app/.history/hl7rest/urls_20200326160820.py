
from . import views
from django.urls import path

urlpatterns = [
    path('server', views.serverInfoView),
    path('ps', views.processView),
    path('pip', views.installedModulesView),
    path('', views.defaultHomeView),
    path('403', views._403View),
    path('hl7', views.ViewHL7),
    path('headers', views.h),


]
