

from django import forms
FAVORITE_COLORS_CHOICES = [
    ('blue', 'Blue'),
    ('green', 'Green'),
    ('black', 'Black'),
]


class Simple_submit_Form(forms.Form):

    format = forms.CharField(max_length=100,
                             widget=forms.TextInput(
                                 attrs={'class': 'form-control', 'placeholder': 'username'})
                             )
    data = forms.CharField(max_length=100, widget=forms.TextInput(
        attrs={'class': 'form-control', 'autocomplete': 'off', 'placeholder': 'password'}))

    """[summary]
    """
    favorite_colors = forms.ChoiceField(
        widget=forms.RadioSelect, choices=FAVORITE_COLORS_CHOICES)
