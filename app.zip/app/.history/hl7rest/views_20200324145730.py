from django.shortcuts import render
from aniachi.systemUtils import Welcome as W
from django.http import JsonResponse, HttpResponse
import json

# Create your views here.


def ServerInfoView(req):
     W.get_all_libs('json')
    return JsonResponse(json.loads(W.get_fetchdata(format='json')), safe=False)


def DefaultHomeView(req):
    return  HttpResponse('<h1>Home</h1>')
