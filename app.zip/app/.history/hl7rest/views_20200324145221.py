from django.shortcuts import render
from aniachi.systemUtils import Welcome as W
from django.http import JsonResponse, HttpResponse

# Create your views here.


def ServerInfoView()
     W.get_all_libs('json')
    return JsonResponse(json.loads(W.get_fetchdata(format='json')), safe=False)
