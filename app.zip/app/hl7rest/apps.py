from django.apps import AppConfig


class Hl7RestConfig(AppConfig):
    name = 'hl7rest'
